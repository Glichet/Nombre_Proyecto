//Se crea una clase que va a realizar una abstraccion de un juego, ya que no se ocupan todos los elementos de este
public abstract class Game {
    protected Game(){}
    protected String tipo_juego = "";
    protected boolean teclas_mapeadas = false;



    // Metodo abstracto que deben emplear las hijas, genera un mapeo de las teclas
    /**
     *
     * El metodo mapear_teclas asigna las teclas segun el dispositivo
     *
     * @param "None"
     * @return null
     */
    abstract protected void mapear_teclas();


    // Metodo que heredan las subclases, simula la ejecucion de un juego
    /**
     *
     * El metodo run simula que el juego se ejecuta
     *
     * @param "None"
     * @return null
     */
    protected void run(){
        System.out.println("Se ejecuta el juego");

    }


    //Se le da el tipo de juego
    protected void setTipo(String tipo) {
        this.tipo_juego = tipo;
    }

    //Sobre carga de generar_juegonue
    /**
     *
     * El metodo generar_juego genera un juego de acuerdo a los parametros de entrada
     *
     * @param "Un string que es el tipo de juego que se va a crear"
     * @return null
     */
    protected void generar_juego(String tipo){
        if (this.teclas_mapeadas){
            System.out.println("Juego generado de tipo" + tipo);
        }

    }
    /**
     *
     * El metodo generar_juego genera un juego de un tipo nuevo
     *
     * @param "None"
     * @return null
     */
    protected void generar_juego(){
        if (this.teclas_mapeadas){
            System.out.println("Nuevo tipo de juego creado");
        }
    }

    @Override
    /**
     *
     * El metodo toString() muestra que tipo de dispositivo corre el juego
     *
     * @param null
     * @return null
     */
    abstract public String toString();
}

