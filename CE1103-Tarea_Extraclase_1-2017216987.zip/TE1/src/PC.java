public class PC extends Game {
    //Se sobre-escribe el metodo de la super clase y se mapean las teclas
    @Override

    protected void mapear_teclas() {

        System.out.println("Se asigna la funcion a W");
        System.out.println("Se asigna la funcion a S");
        System.out.println("Se asigna la funcion a A");
        System.out.println("Se asigna la funcion a D");



    }

    @Override
    public String toString() {
        return "Computadora Personal";
    }

}
