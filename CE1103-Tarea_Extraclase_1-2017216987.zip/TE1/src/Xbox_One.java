public class Xbox_One extends Game {

    @Override
    protected void mapear_teclas() {
        System.out.println("Se asigna la funcion a A");
        System.out.println("Se asigna la funcion a B");
        System.out.println("Se asigna la funcion a X");
        System.out.println("Se asigna la funcion a Y");
        this.teclas_mapeadas = true;


    }

    @Override
    public String toString() {
        return "Xbox One";
    }


}
