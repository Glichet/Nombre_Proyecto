public class PS4 extends Game{


    @Override
    protected void mapear_teclas() {
        System.out.println("Se asigna la funcion a Equis");
        System.out.println("Se asigna la funcion a Circulo");
        System.out.println("Se asigna la funcion a Cuadrado");
        System.out.println("Se asigna la funcion a Triangulo");



    }

    @Override
    public String toString() {
        return "Playstation 4";
    }
}
