/**
Contexto

Una compañia de videojuegos tiene un programa en java que genera los ports de sus juegos a distintas consolas
 @author Joseph Gonzalez Pastora
 @
 */


import java.util.Scanner;

public class Main {

    public static void main(String[] args){
        //Instanciación de la clases hijas
        PC juego_1 = new PC();
        PS4 juego_2 = new PS4();
        Xbox_One juego_3 = new Xbox_One();
        // Instanciacion de Scanner
        Scanner input = new Scanner(System.in);
        //
        System.out.println("Ingrese el tipo de juego");
        String juego_tipo = input.nextLine();
        //Se crea un array
        Game[] array_juego = new Game[3];
        array_juego[0] = juego_1;
        array_juego[1] = juego_2;
        array_juego[2] = juego_3;

        for (int i =0; i<3;i++){
            if (juego_tipo.equals("nuevo")){
                System.out.println(array_juego[i]);
                array_juego[i].mapear_teclas();
                array_juego[i].generar_juego();

            }
            else{
                System.out.println(array_juego[i]);
                array_juego[i].mapear_teclas();
                array_juego[i].generar_juego(juego_tipo);

            }




        }




    }

}
